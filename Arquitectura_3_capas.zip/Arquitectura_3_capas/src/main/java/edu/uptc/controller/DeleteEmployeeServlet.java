package edu.uptc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.uptc.model.Employee;

/**
 * Servlet implementation class DeleteEmployeeServlet
 */
@WebServlet("/DeleteEmployeeServlet")
public class DeleteEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		employeeList = (ArrayList<Employee>) request.getSession().getAttribute("lista");
		int idEmployee =  Integer.parseInt((String)request.getParameter("employee_id_DELETE"));
		for (Employee empl: employeeList) {
			if (empl.getEmp_id() == idEmployee ) {
				employeeList.remove(empl);
				break;
			}
			
		}
		request.getSession().setAttribute("lista", employeeList);
		PrintWriter out;
	    out = response.getWriter();
        response.setContentType("text/html");
		out.println("<html>");
		out.println("<head><style>\"/css/empStyle.css\"></style> <title>Respuesta editar empleado</title></head>");
		out.println("<body>");
		out.println("<h1> EMPLOYEE APP</h1>");
		out.println("<h2> Se ha eliminado el empleado </h2>");
		out.println("<input type=button onClick=\"parent.location='index.jsp'\"value='Aceptar'>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
