package edu.uptc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import edu.uptc.model.Employee;


/**
 * Servlet implementation class UpdatePersonaServlet
 */
@WebServlet("/ShowAllEmployeeServlet")
public class ShowAllEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if (request.getSession().getAttribute("lista")!=null ) {
			ArrayList<Employee> lista =(ArrayList<Employee>)request.getSession().getAttribute("lista");
			int count = 0;
			Employee emp = new Employee();
			for (int i = 0; i < lista.size(); i++) {
				if (lista.get(i) != null && lista.size()>=2) {
					String ids= String.valueOf(lista.get(i).getEmp_id());
					String name = lista.get(i).getEmp_name();
					String email = lista.get(i).getEmail_emp();
					String phone = String.valueOf(lista.get(i).getPhone_emp());
					request.setAttribute("emp_id", ids);
					request.setAttribute("emp_name", name);
					request.setAttribute("emp_email", email);
					request.setAttribute("emp_phone", phone);
					
					break;
				}
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/showAllEmployees.jsp");
	        dispatcher.forward(request, response);
		}else {
			PrintWriter out;
		    out = response.getWriter();
	        response.setContentType("text/html");
			out.println("<html>");
			out.println("<head><style>\"/css/empStyle.css\"></style> <title>Respuesta editar empleado</title></head>");
			out.println("<body>");
			out.println("<h1> EMPLOYEE APP</h1>");
			out.println("<h2> No hay empleados registrados!  </h2>");
			out.println("<a href=\"index.jsp\"> Volver a la p�gina inicial!</h2>");
			out.println("</body></html>");
		}
		//response.sendRedirect(request.getContextPath() + "/updatePerson.jsp");
	}
	
}
