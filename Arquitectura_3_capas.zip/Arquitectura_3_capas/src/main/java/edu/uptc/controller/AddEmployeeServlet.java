package edu.uptc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.uptc.model.Employee;
import edu.uptc.model.EmployeeManager;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/AddEmployeeServlet")
public class AddEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeManager em = new EmployeeManager();
	/**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.valueOf(request.getParameter("emp_id"));
		String name = request.getParameter("emp_name");
		String email = request.getParameter("emp_email");
		long phone = Long.valueOf(request.getParameter("emp_phone"));
		Employee emp = new Employee();
		emp.setEmp_id(id);
		emp.setEmp_name(name);
		emp.setEmail_emp(email);
		emp.setPhone_emp(phone);
		ArrayList<Employee> employeeList;
		employeeList = (ArrayList<Employee>) request.getSession().getAttribute("lista");
		if (employeeList!=null ) {
			employeeList.add(emp);
		}else{
			employeeList = new ArrayList<Employee>();
			employeeList.add(emp);
		}
		request.getSession().setAttribute("lista", employeeList);
		
		request.getRequestDispatcher("/result.jsp").forward(request, response);
	}
	

}
